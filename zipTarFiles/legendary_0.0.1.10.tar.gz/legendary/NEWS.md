legendary 0.0.1.10 (2021-02-02)
* Internal reorganization of positioning section into its own function.

legendary 0.0.1.9 (2020-10-11)
* Added more formatting arguments to legendGrad().

legendary 0.0.1.8 (2020-07-09)
* Fixed bug in legendGrad().

legendary 0.0.1.7 (2020-06-11)
* Amended function legendGrad() so user can specify pos argument to text.
