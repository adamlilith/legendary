legendary 0.0.1.8 (2020-07-09)
* Fixed bug in legendGrad().

legendary 0.0.1.7 (2020-06-11)
* Amended function legendGrad() so user can specify pos argument to text.
